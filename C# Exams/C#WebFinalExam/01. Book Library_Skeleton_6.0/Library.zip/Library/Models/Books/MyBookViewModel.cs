﻿namespace Library.Models.Books
{
    public class MyBookViewModel : AllBookViewModel
    {
        public string Description { get; set; }
    }
}
