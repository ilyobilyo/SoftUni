﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.InputModels
{
    public class InputSuppliersModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public bool IsImporter { get; set; }

    }
}
