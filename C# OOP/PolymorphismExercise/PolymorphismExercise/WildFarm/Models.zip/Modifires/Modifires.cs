﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Modifires
{
    public static class Modifires
    {
        public static double HenValue = 0.35;

        public static double OwlValue = 0.25;

        public static double MouseValue = 0.10;

        public static double CatValue = 0.30;

        public static double DogValue = 0.40;

        public static double TigerValue = 1.00;

    }
}
