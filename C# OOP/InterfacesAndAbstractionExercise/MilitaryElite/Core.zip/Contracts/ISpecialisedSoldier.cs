﻿namespace MilitaryElite.Contracts
{
    public interface ISpecialisedSoldier : IPrivate
    {
         string Corp { get; set; }
    }
}
