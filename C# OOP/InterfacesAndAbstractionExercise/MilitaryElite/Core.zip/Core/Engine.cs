﻿using MilitaryElite.Contracts;
using MilitaryElite.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Core
{
    public class Engine
    {
        private Dictionary<string, ISoldier> soldiers = new Dictionary<string, ISoldier>();

        public void Run()
        {
            while (true)
            {
                string input = Console.ReadLine();
                if (input == "End")
                {
                    break;
                }

                string[] personInfo = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                ReadSoldiers(personInfo);
            }

            PrintSoldiers();
        }

        public void ReadSoldiers(string[] personInfo)
        {
            string id = personInfo[1];
            string firstName = personInfo[2];
            string lastName = personInfo[3];


            if (personInfo[0] == "Private")
            {
                decimal salary = decimal.Parse(personInfo[4]);

                ISoldier currentPrivate = new Private(id, firstName, lastName, salary);

                soldiers.Add(id, currentPrivate);
            }
            else if (personInfo[0] == "LieutenantGeneral")
            {
                decimal salary = decimal.Parse(personInfo[4]);

                ILieutenantGeneral lieutenant = new LieutenantGeneral(id, firstName, lastName, salary);

                for (int i = 5; i < personInfo.Length; i++)
                {
                    ISoldier soldier = soldiers[personInfo[i]];
                    lieutenant.AddPrivate(soldier);
                }

                soldiers.Add(id, lieutenant);
            }
            else if (personInfo[0] == "Engineer")
            {
                decimal salary = decimal.Parse(personInfo[4]);
                string corp = personInfo[5];
                try
                {
                    IEngineer engineer = new Engineer(id, firstName, lastName, salary, corp);

                    for (int i = 6; i < personInfo.Length; i+=2)
                    {
                        IRepair repair = new Repair(personInfo[i], int.Parse(personInfo[i + 1]));
                        engineer.AddRepair(repair);
                    }

                    soldiers.Add(id, engineer);
                }
                catch (Exception ex)
                {
                    
                }

            }
            else if (personInfo[0] == "Commando")
            {
                decimal salary = decimal.Parse(personInfo[4]);
                string corp = personInfo[5];

                try
                {
                    ICommando commando = new Commando(id, firstName, lastName, salary, corp);

                    for (int i = 6; i < personInfo.Length; i+=2)
                    {
                        if (personInfo[i+1] != "inProgress" && personInfo[i+1] != "Finished")
                        {
                            continue;
                        }

                        IMission mission = new Mission(personInfo[i], personInfo[i + 1]);
                        commando.AddMission(mission);
                    }

                    soldiers.Add(id, commando);
                }
                catch (Exception ex)
                {
                    
                }
            }
            else if (personInfo[0] == "Spy")
            {
                int codeNumber = int.Parse(personInfo[4]);

                ISoldier spy = new Spy(id, firstName, lastName, codeNumber);
                soldiers.Add(id, spy);
            }
        }

        public void PrintSoldiers()
        {
            foreach (var soldier in soldiers)
            {
                Console.WriteLine(soldier.Value);
            }
        }
    }

}
