﻿using System;

namespace CustomLinkedList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //DoublyLinkedList<int> list = new DoublyLinkedList<int>();
            //list.AddFirst(1);
            //list.AddFirst(2);
            //list.AddFirst(3);
            //list.AddFirst(4);

            //list.AddLast(5);
            //list.AddLast(6);
            //list.AddLast(7);
            //list.AddLast(8);

            //list.RemoveFirst();
            //list.RemoveLast();

            //list.ForEach(x => Console.WriteLine(x));
        }
    }
}
